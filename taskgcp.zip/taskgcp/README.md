# taskgcp
3 tier app in GCP 
